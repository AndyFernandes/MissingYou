package br.ufc.missingyou.view.activitys;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import br.ufc.missingyou.R;


public class QuadroCampanhasCadastradas extends AppCompatActivity implements  View.OnClickListener {


    public QuadroCampanhasCadastradas() {
        // Required empty public constructor
    }
    private ViewHolder mViewHolder = new ViewHolder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_quadro_campanhas_cadastradas);
        this.mViewHolder.nomeDesaparecido = (TextView) findViewById(R.id.nomePessoa);
        this.mViewHolder.localDesaparecimento = (TextView) findViewById(R.id.local_desaparecimento);
        this.mViewHolder.dataDesaparecimento = (TextView) findViewById(R.id.data_desaparecimento);
        this.mViewHolder.dataNascimentoDesaparecido = (TextView) findViewById(R.id.data_nascimento);
        this.mViewHolder.cabeloDesaparecido = (TextView) findViewById(R.id.cabelo);
        this.mViewHolder.olhosDesaparecido = (TextView) findViewById(R.id.olho);
        this.mViewHolder.racaDesaparecido = (TextView) findViewById(R.id.raca);
        this.mViewHolder.sexoDesaparecido = (TextView) findViewById(R.id.genero);
        this.mViewHolder.foto = (ImageView) findViewById(R.id.foto_desaparecido);

        this.mViewHolder.alterarDados = (Button) findViewById(R.id.alterarDados);
        this.mViewHolder.gerarFolder = (Button) findViewById(R.id.gerarFolder);
        this.mViewHolder.notificacoes = (Button) findViewById(R.id.notificacoes);

        this.mViewHolder.alterarDados.setOnClickListener(this);
        this.mViewHolder.gerarFolder.setOnClickListener(this);
        this.mViewHolder.notificacoes.setOnClickListener(this);

    }

    private static class ViewHolder {
        ImageView foto;
        Button alterarDados;
        Button notificacoes;
        Button gerarFolder;
        TextView nomeDesaparecido;
        TextView dataNascimentoDesaparecido;
        TextView dataDesaparecimento;
        TextView olhosDesaparecido;
        TextView cabeloDesaparecido;
        TextView sexoDesaparecido;
        TextView racaDesaparecido;
        TextView localDesaparecimento;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if(id == R.id.alterarDados) {
            // Ta ok, so redireciona para uma pagina tb
            Intent intent = new Intent(this, AtualizarCampanhaActivity.class);
            startActivity(intent);
        } else if (id == R.id.gerarFolder){
            //Esse tem que fazer
        } else if (id == R.id.notificacoes){
            // Nao sei bem, mas tem que fazer tambem
        }
    }


}
